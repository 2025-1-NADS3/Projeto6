package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button buttonContinuar = findViewById(R.id.btn_continuar);
        buttonContinuar.setOnClickListener(v -> {
            // CORRIGIDO: vai para HomeActivity, não para MainActivity
            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // Fecha LoginActivity
        });

        Button buttonVoltar = findViewById(R.id.btn_voltar);
        buttonVoltar.setOnClickListener(v -> finish()); // Volta para MainActivity
    }
}
