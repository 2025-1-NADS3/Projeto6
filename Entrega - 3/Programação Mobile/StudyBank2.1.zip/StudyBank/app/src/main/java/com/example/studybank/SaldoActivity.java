package com.example.studybank;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SaldoActivity extends AppCompatActivity {

    private ImageButton backButton;
    private ImageView copyIcon1, copyIcon2, copyIcon3;
    private TextView chave1, chave2, chave3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saldo); // Certifique-se que o nome do layout está correto

        // Botão de voltar
        backButton = findViewById(R.id.imageButton4);
        backButton.setOnClickListener(v -> finish()); // Voltar para a tela anterior

        // Referências de TextViews das chaves Pix
        chave1 = findViewById(R.id.textView40);
        chave2 = findViewById(R.id.textView39);
        chave3 = findViewById(R.id.textView38);

        // Ícones de cópia
        copyIcon1 = findViewById(R.id.imageView75);
        copyIcon2 = findViewById(R.id.imageView79);
        copyIcon3 = findViewById(R.id.imageView57);

        // Funções de cópia para cada chave
        copyIcon1.setOnClickListener(view -> copiarChave(chave1.getText().toString()));
        copyIcon2.setOnClickListener(view -> copiarChave(chave2.getText().toString()));
        copyIcon3.setOnClickListener(view -> copiarChave(chave3.getText().toString()));
    }

    private void copiarChave(String texto) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Chave Pix", texto);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, "Chave Pix copiada!", Toast.LENGTH_SHORT).show();
    }
}
