package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText senhaEditText;
    private RequestQueue requestQueue;

    private static final String LOGIN_URL = "https://ympr79-3001.csb.app/api/usuarios/login"; // Seu endpoint de login

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailEditText = findViewById(R.id.email_edit_text);
        senhaEditText = findViewById(R.id.senha_edit_text);
        Button buttonContinuar = findViewById(R.id.btn_continuar);
        ImageButton buttonVoltar = findViewById(R.id.btn_voltar);

        requestQueue = Volley.newRequestQueue(this);

        buttonContinuar.setOnClickListener(v -> {
            String email = emailEditText.getText().toString().trim();
            String senha = senhaEditText.getText().toString().trim();

            if (email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            fazerLogin(email, senha);
        });

        buttonVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void fazerLogin(String email, String senha) {
        try {
            JSONObject dadosLogin = new JSONObject();
            dadosLogin.put("email", email);
            dadosLogin.put("senha", senha);

            JsonObjectRequest requisicao = new JsonObjectRequest(
                    Request.Method.POST,
                    LOGIN_URL,
                    dadosLogin,
                    response -> {
                        // Sucesso: navega para Home
                        Toast.makeText(LoginActivity.this, "Login realizado com sucesso", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        intent.putExtra("nome_usuario", email); // Envia email ou nome, se desejar
                        startActivity(intent);
                        finish();
                    },
                    error -> {
                        // Erro: mostra mensagem
                        Toast.makeText(LoginActivity.this, "Erro no login. Verifique suas credenciais.", Toast.LENGTH_LONG).show();
                    }
            );

            requestQueue.add(requisicao);

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao criar dados de login", Toast.LENGTH_SHORT).show();
        }
    }
}
