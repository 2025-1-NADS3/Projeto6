package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private boolean saldoVisivel = false;
    private double saldoReal = 1234.56;

    private TextView textViewSaldo;
    private ImageView imageViewOlho;

    private ActivityResultLauncher<Intent> pagamentoLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView textViewNome = findViewById(R.id.textView);
        Intent intent = getIntent();
        String nomeUsuario = intent.getStringExtra("nome_usuario");
        if (nomeUsuario != null) {
            textViewNome.setText("Olá, " + nomeUsuario);
        }

        textViewSaldo = findViewById(R.id.textView7);
        imageViewOlho = findViewById(R.id.imageView6);
        atualizarTextoSaldo();

        imageViewOlho.setOnClickListener(v -> {
            saldoVisivel = !saldoVisivel;
            atualizarTextoSaldo();
        });

        ImageButton btnSair = findViewById(R.id.btn_voltar);
        btnSair.setOnClickListener(v -> {
            Intent sairIntent = new Intent(HomeActivity.this, LoginActivity.class);
            startActivity(sairIntent);
            finish();
        });

        findViewById(R.id.imageView9).setOnClickListener(v -> startActivity(new Intent(this, BoletoActivity.class)));
        findViewById(R.id.imageView14).setOnClickListener(v -> startActivity(new Intent(this, InvestirActivity.class)));
        findViewById(R.id.imageView15).setOnClickListener(v -> startActivity(new Intent(this, PixActivity.class)));
        findViewById(R.id.imageView16).setOnClickListener(v -> startActivity(new Intent(this, SegurancaActivity.class)));

        pagamentoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        saldoReal = result.getData().getDoubleExtra("novoSaldo", saldoReal);
                        atualizarTextoSaldo();
                    }
                }
        );

        ImageView imageViewPagamento = findViewById(R.id.imageView10);
        imageViewPagamento.setOnClickListener(v -> {
            Intent pagamentoIntent = new Intent(this, PagamentoActivity.class);
            pagamentoIntent.putExtra("saldo", formatarSaldo(saldoReal));
            pagamentoLauncher.launch(pagamentoIntent);
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.hasExtra("novoSaldo")) {
            saldoReal = intent.getDoubleExtra("novoSaldo", saldoReal);
            atualizarTextoSaldo();
        }
    }

    private void atualizarTextoSaldo() {
        if (saldoVisivel) {
            textViewSaldo.setText(formatarSaldo(saldoReal));
            imageViewOlho.setImageResource(R.drawable.eye);
        } else {
            textViewSaldo.setText("R$ ... ... ...");
            imageViewOlho.setImageResource(R.drawable.closeye);
        }
    }

    private String formatarSaldo(double valor) {
        return String.format("R$ %.2f", valor).replace('.', ',');
    }
}
