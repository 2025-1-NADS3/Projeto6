package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TransferirActivity extends AppCompatActivity {

    private EditText editTextChavePix;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transferir);

        editTextChavePix = findViewById(R.id.editTextChavePix2);
        Button btnContinuar = findViewById(R.id.btn_continuar2);
        ImageButton btnVoltar = findViewById(R.id.imageButton7);

        // Botão "Voltar"
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Volta para a activity anterior
            }
        });

        // Botão "Continuar"
        btnContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String chavePix = editTextChavePix.getText().toString().trim();

                if (chavePix.isEmpty()) {
                    Toast.makeText(TransferirActivity.this, "Digite a chave Pix", Toast.LENGTH_SHORT).show();
                } else {
                    // Aqui você pode ir para a próxima tela com a chave Pix
                    Intent intent = new Intent(TransferirActivity.this, PagamentoActivity.class); // substitua pela sua próxima Activity
                    intent.putExtra("chave_pix", chavePix);
                    startActivity(intent);
                }
            }
        });
    }
}
