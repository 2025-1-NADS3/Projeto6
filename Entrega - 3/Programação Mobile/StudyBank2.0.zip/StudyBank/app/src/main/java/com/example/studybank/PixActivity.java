package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class PixActivity extends AppCompatActivity {

    private ImageButton backButton;
    private ImageView imageViewTransferir;
    private ImageView imageViewSaldo;
    private ImageView imageView5;  // Novo ImageView para abrir QRActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pix);

        backButton = findViewById(R.id.imageButton2);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(PixActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        });

        imageViewTransferir = findViewById(R.id.imageView3);
        imageViewTransferir.setOnClickListener(v -> {
            Intent intent = new Intent(PixActivity.this, TransferirActivity.class);
            startActivity(intent);
        });

        imageViewSaldo = findViewById(R.id.imageView21);
        imageViewSaldo.setOnClickListener(v -> {
            Intent intent = new Intent(PixActivity.this, SaldoActivity.class);
            startActivity(intent);
        });

        imageView5 = findViewById(R.id.imageView5);
        imageView5.setOnClickListener(v -> {
            Intent intent = new Intent(PixActivity.this, QRActivity.class);
            startActivity(intent);
        });
    }
}
