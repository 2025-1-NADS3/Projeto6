package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PagamentoActivity extends AppCompatActivity {

    private boolean saldoVisivel = false;
    private String saldoReal = "R$ 0,00";
    private double saldoDouble = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamento);

        ImageButton btnVoltar = findViewById(R.id.imageButton8);
        Button btnContinuar = findViewById(R.id.btn_continuar3);
        EditText editValor = findViewById(R.id.editTextChavePix3);
        TextView textSaldo = findViewById(R.id.textView32);
        ImageView olho = findViewById(R.id.imageView54);

        // Recuperar o saldo vindo da HomeActivity
        Intent intent = getIntent();
        saldoReal = intent.getStringExtra("saldo");

        if (saldoReal == null || saldoReal.isEmpty()) {
            saldoReal = "R$ 1.234,56";
        }

        saldoDouble = parseSaldo(saldoReal);

        textSaldo.setText("Saldo em conta: R$ ...");
        olho.setImageResource(R.drawable.closeye);

        olho.setOnClickListener(v -> {
            if (saldoVisivel) {
                textSaldo.setText("Saldo em conta: R$ ...");
                olho.setImageResource(R.drawable.closeye);
            } else {
                textSaldo.setText("Saldo em conta: " + saldoReal);
                olho.setImageResource(R.drawable.eye);
            }
            saldoVisivel = !saldoVisivel;
        });

        btnVoltar.setOnClickListener(v -> finish());

        btnContinuar.setOnClickListener(v -> {
            String valorDigitado = editValor.getText().toString().replace("R$", "").replace(",", ".").trim();

            if (valorDigitado.isEmpty()) {
                Toast.makeText(PagamentoActivity.this, "Digite um valor para transferir", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double valorTransferencia = Double.parseDouble(valorDigitado);

                if (valorTransferencia <= 0) {
                    Toast.makeText(PagamentoActivity.this, "Valor inválido", Toast.LENGTH_SHORT).show();
                } else if (valorTransferencia > saldoDouble) {
                    Toast.makeText(PagamentoActivity.this, "Saldo insuficiente", Toast.LENGTH_SHORT).show();
                } else {
                    double novoSaldo = saldoDouble - valorTransferencia;

                    Toast.makeText(PagamentoActivity.this, "Transferência realizada com sucesso!", Toast.LENGTH_LONG).show();

                    Intent intentVoltar = new Intent(PagamentoActivity.this, HomeActivity.class);
                    intentVoltar.putExtra("novoSaldo", novoSaldo);
                    intentVoltar.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intentVoltar);
                    finish();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(PagamentoActivity.this, "Erro ao processar valor", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private double parseSaldo(String saldoTexto) {
        try {
            saldoTexto = saldoTexto.replace("R$", "").replace(".", "").replace(",", ".").trim();
            return Double.parseDouble(saldoTexto);
        } catch (Exception e) {
            return 0.0;
        }
    }
}
