
package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.NetworkResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

public class CadastroActivity extends AppCompatActivity {

    private EditText nomeEditText, emailEditText, enderecoEditText, senhaEditText, repetirSenhaEditText;
    private static final String CADASTRO_URL = "https://ympr79-3001.csb.app/api/usuarios/cadastro";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        nomeEditText = findViewById(R.id.edit_nome);
        emailEditText = findViewById(R.id.edit_email);
        enderecoEditText = findViewById(R.id.edit_endereco);
        senhaEditText = findViewById(R.id.edit_senha);
        repetirSenhaEditText = findViewById(R.id.edit_repetir_senha);

        ImageButton btnVoltar = findViewById(R.id.btn_voltar);
        Button btnContinuar = findViewById(R.id.btn_continuar);

        btnVoltar.setOnClickListener(v -> finish());

        btnContinuar.setOnClickListener(v -> realizarCadastro());
    }

    private void realizarCadastro() {
        String nome = nomeEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String endereco = enderecoEditText.getText().toString().trim();
        String senha = senhaEditText.getText().toString().trim();
        String repetirSenha = repetirSenhaEditText.getText().toString().trim();

        if (nome.isEmpty() || email.isEmpty() || endereco.isEmpty() || senha.isEmpty() || repetirSenha.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!senha.equals(repetirSenha)) {
            Toast.makeText(this, "As senhas não conferem", Toast.LENGTH_SHORT).show();
            return;
        }

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("nome", nome);
            jsonBody.put("email", email);
            jsonBody.put("endereco", endereco);
            jsonBody.put("senha", senha);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao criar dados para cadastro.", Toast.LENGTH_SHORT).show();
            return;
        }

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                CADASTRO_URL,
                jsonBody,
                response -> {
                    Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(CadastroActivity.this, LoginActivity.class));
                    finish();
                },
                error -> {
                    String errorMessage = "Erro ao cadastrar. Verifique os dados e tente novamente.";

                    NetworkResponse networkResponse = error.networkResponse;
                    if (networkResponse != null && networkResponse.data != null) {
                        String responseBody = new String(networkResponse.data, StandardCharsets.UTF_8);
                        try {
                            JSONObject data = new JSONObject(responseBody);
                            if (data.has("message")) {
                                errorMessage = data.getString("message");
                            } else if (data.has("error")) {
                                errorMessage = data.getString("error");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
                    Log.e("CadastroError", errorMessage);
                }
        );

        queue.add(request);
    }
}
