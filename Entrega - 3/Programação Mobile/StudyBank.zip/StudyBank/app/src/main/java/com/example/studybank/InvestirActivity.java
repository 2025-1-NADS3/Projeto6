package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class InvestirActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_investir); // Certifique-se que o XML tem esse nome no res/layout

        // Botão de voltar para a tela Home
        ImageButton btnVoltar = findViewById(R.id.imageButton6);
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InvestirActivity.this, HomeActivity.class);
                startActivity(intent);
                finish(); // Fecha a tela atual
            }
        });
    }
}
