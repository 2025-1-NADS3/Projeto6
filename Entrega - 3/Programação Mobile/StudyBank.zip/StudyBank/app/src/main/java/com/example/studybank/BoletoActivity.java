package com.example.studybank;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class BoletoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boleto); // Nome do seu XML

        // Botão de voltar para Home
        ImageButton btnVoltar = findViewById(R.id.imageButton3);
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BoletoActivity.this, HomeActivity.class);
                startActivity(intent);
                finish(); // Encerra a tela atual
            }
        });
    }
}
